import Image from "next/image"

export function About() {
  return (
    <section id="about" className="bg-card py-24">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="mb-3 text-sm font-medium uppercase tracking-[0.2em] text-primary">
            Meet Your Host
          </p>
          <h2 className="text-balance font-serif text-3xl font-bold text-card-foreground md:text-4xl">
            Building connections that matter
          </h2>
        </div>

        <div className="mt-16 flex flex-col items-center gap-12 md:flex-row md:gap-16">
          <div className="relative flex-shrink-0">
            <div className="relative h-96 w-72 overflow-hidden rounded-2xl border-2 border-primary/20">
              <Image
                src="/images/host.jpg"
                alt="Host of CityLocal"
                fill
                priority
                className="object-contain object-center"
              />
            </div>
            <div className="absolute -bottom-4 -right-4 rounded-lg bg-primary px-4 py-2">
              <span className="text-sm font-semibold text-primary-foreground">Host</span>
            </div>
          </div>

          <div className="flex-1 text-center md:text-left">
            <p className="text-lg leading-relaxed text-muted-foreground">
              I&apos;m passionate about working with leaders who want to make a real
              difference in their communities and the environment.
            </p>
            <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
              Building the right partnerships is at the core of how I work and what
              drives my results. I&apos;m trustworthy, accountable, and intuitive. These
              are qualities I believe are essential for meaningful, long-term
              relationships.
            </p>
            <div className="mt-8">
              <a
                href="#contact"
                className="inline-block rounded-md bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
              >
                Become a Member
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
