export function Footer() {
  return (
    <footer className="border-t border-border bg-card py-12">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-6 px-6 md:flex-row md:justify-between">
        <div className="flex flex-col items-center gap-1 md:items-start">
          <span className="font-serif text-lg font-bold text-primary">CityLocal</span>
          <span className="text-xs text-muted-foreground">
            Membership & Exclusive Partnerships
          </span>
        </div>

        <div className="flex items-center gap-6">
          <a
            href="#about"
            className="text-sm text-muted-foreground transition-colors hover:text-primary"
          >
            About
          </a>
          <a
            href="#events"
            className="text-sm text-muted-foreground transition-colors hover:text-primary"
          >
            Events
          </a>
          <a
            href="#membership"
            className="text-sm text-muted-foreground transition-colors hover:text-primary"
          >
            Membership
          </a>
          <a
            href="#contact"
            className="text-sm text-muted-foreground transition-colors hover:text-primary"
          >
            Contact
          </a>
        </div>

        <p className="text-xs text-muted-foreground">
          {"\u00A9"} {new Date().getFullYear()} CityLocal. All rights reserved.
        </p>
      </div>
    </footer>
  )
}
