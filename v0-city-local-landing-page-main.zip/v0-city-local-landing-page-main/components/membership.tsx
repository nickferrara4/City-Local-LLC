import { Check } from "lucide-react"

const benefits = [
  "Priority access to all CityLocal events",
  "Curated introductions to sponsor partners",
  "Private roundtable invitations",
  "Dedicated membership concierge",
  "Exclusive member directory access",
  "Quarterly business growth workshops",
  "Access to capital or customers",
]

export function Membership() {
  return (
    <section id="membership" className="bg-card py-24">
      <div className="mx-auto max-w-6xl px-6">
        <div className="grid items-center gap-12 md:grid-cols-2">
          {/* Left column */}
          <div>
            <p className="mb-3 text-sm font-medium uppercase tracking-[0.2em] text-primary">
              Membership
            </p>
            <h2 className="text-balance font-serif text-3xl font-bold text-card-foreground md:text-4xl">
              Join the inner circle
            </h2>
            <p className="mt-4 max-w-lg text-pretty leading-relaxed text-muted-foreground">
              CityLocal membership opens the door to a curated network of business
              leaders, exclusive events, and partnerships that accelerate your growth.
            </p>
            <a
              href="#contact"
              className="mt-8 inline-block rounded-md bg-primary px-8 py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
            >
              Become a Member
            </a>
          </div>

          {/* Right column - benefits */}
          <div className="rounded-lg border border-border bg-background p-8">
            <h3 className="mb-6 text-lg font-semibold text-foreground">
              Member Benefits
            </h3>
            <ul className="flex flex-col gap-4">
              {benefits.map((benefit) => (
                <li key={benefit} className="flex items-start gap-3">
                  <div className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/15">
                    <Check className="h-3 w-3 text-primary" />
                  </div>
                  <span className="leading-relaxed text-muted-foreground">
                    {benefit}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
