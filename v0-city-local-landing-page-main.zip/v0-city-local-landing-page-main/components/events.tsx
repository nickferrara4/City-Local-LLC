const stats = [
  { value: "50+", label: "Events Hosted" },
  { value: "500+", label: "Active Members" },
  { value: "$5M+", label: "Revenue Generated for Members" },
]

export function Events() {
  return (
    <section id="events" className="bg-background py-24">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="mb-3 text-sm font-medium uppercase tracking-[0.2em] text-primary">
            By the Numbers
          </p>
          <h2 className="text-balance font-serif text-3xl font-bold text-foreground md:text-4xl">
            Real impact, real results
          </h2>
        </div>

        <div className="mt-16 grid grid-cols-3 gap-6">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="flex flex-col items-center rounded-lg border border-border bg-card p-8 text-center"
            >
              <span className="font-serif text-3xl font-bold text-primary md:text-4xl">
                {stat.value}
              </span>
              <span className="mt-2 text-sm leading-snug text-muted-foreground">
                {stat.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
