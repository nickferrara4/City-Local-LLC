import Image from "next/image"
import { ArrowDown } from "lucide-react"

export function Hero() {
  return (
    <section className="relative flex min-h-screen items-center justify-center overflow-hidden">
      {/* Background image */}
      <Image
        src="/images/hero-event.jpg"
        alt="Elegant business networking event"
        fill
        className="object-cover"
        priority
      />

      {/* Overlay */}
      <div className="absolute inset-0 bg-background/75" />

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-4xl px-6 text-center">
        <p className="mb-4 text-sm font-medium uppercase tracking-[0.25em] text-primary">
          Membership & Exclusive Partnerships
        </p>
        <h1 className="text-balance font-serif text-4xl font-bold leading-tight text-foreground md:text-6xl lg:text-7xl">
          Join Now
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg leading-relaxed text-muted-foreground md:text-xl">
          CityLocal brings together the most ambitious business leaders through
          curated events, building connections that drive real growth.
        </p>
        <div className="mt-10 flex justify-center">
          <a
            href="#contact"
            className="rounded-md bg-primary px-8 py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
          >
            Become a Member
          </a>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 z-10 -translate-x-1/2">
        <a href="#about" aria-label="Scroll to learn more">
          <ArrowDown className="h-5 w-5 animate-bounce text-muted-foreground" />
        </a>
      </div>
    </section>
  )
}
